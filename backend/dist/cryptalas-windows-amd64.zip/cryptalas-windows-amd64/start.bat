@echo off
REM CryptALAS agent — start with the GPU trainer wired.
REM Use -tty instead of the flags below for an interactive terminal.
cryptalas.exe --addr 127.0.0.1:8810 --device cuda --cuda-runner gpu\cuda_train.py
pause
