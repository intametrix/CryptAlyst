CryptALAS agent — Windows (amd64)
=================================

What's here
  cryptalas.exe        the agent (train job runner, HTTP + TTY)
  gpu\cuda_train.py    the CUDA/GPU trainer (JAX/PyTorch with CPU fallback)
  start.bat            run the agent with the GPU trainer wired

Requirements
  - 64-bit Windows 10/11
  - Python 3 (for GPU/CUDA training; optional — the agent runs without it
    on the CPU path)
  - NVIDIA driver + (optional) pip install jax[cuda]  or  torch  for real
    GPU acceleration

Quick start
  1. Double-click start.bat   (or run from a terminal)
  2. The agent listens on http://127.0.0.1:8810
     - GET  /gpu      -> machine/GPU report
     - POST /jobs     -> submit a train job  {model, type:"train", device:"cuda", payload:{rows:[...]}}
     - GET  /jobs/    -> job list   GET /jobs/<id> -> one job

Flags (cryptalas.exe -h)
  -addr            listen address        (default 127.0.0.1:8810)
  -device          auto|cpu|gpu|cuda|metal
  -cuda-runner     path to gpu\cuda_train.py
  -ollama          Ollama base URL (GPU box)
  -state           job state directory
  -tty             interactive terminal instead of the HTTP server

Device note
  The trainer reports the device it actually used. Without an NVIDIA GPU it
  falls back to CPU and says so — the result shape is identical either way.
